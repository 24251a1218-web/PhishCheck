# AI Phishing Detection

Detect phishing URLs and emails using AI/ML.

## Features
- Detect phishing websites and emails
- Web interface for input
- Visual reports

## Setup
```bash
git clone <repo-url>
cd AI-Phishing-Detection
pip install -r requirements.txt
python app/main.py
```

## Folder Structure
- `app/` - main app files
- `data/` - datasets
- `notebook/` - exploration and analysis
- `tests/` - unit tests
