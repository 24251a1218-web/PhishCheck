# Utility functions can go here
def clean_url(url):
    return url.strip().lower()
