# Placeholder model
# In real use, replace with trained model
def predict_phishing(url):
    phishing_keywords = ["login", "verify", "bank", "update", "secure"]
    if any(word in url.lower() for word in phishing_keywords):
        return "Phishing"
    return "Legitimate"
