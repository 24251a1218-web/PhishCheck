from app.model import predict_phishing

def test_phishing():
    assert predict_phishing("http://secure-bank-login.com") == "Phishing"
    assert predict_phishing("http://example.com") == "Legitimate"

if __name__ == "__main__":
    test_phishing()
    print("All tests passed!")
